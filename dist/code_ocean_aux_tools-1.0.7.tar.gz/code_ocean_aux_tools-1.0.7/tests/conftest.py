import pytest

from .fixtures.dirs_of_files import fastq_dir, results_dir
from .fixtures.fastq_file import fastq_file_fwd, fastq_file_single_end
from .fixtures.sample_sheets import mocker_samplesheet
