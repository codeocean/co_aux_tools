#!/usr/bin/env bash

echo "get_cpu_count says $(get_cpu_count)"
echo "The last exit status was $?"

echo "get_dir_content says: $(get_dir_contents)"
echo "The last exit status was $?"










