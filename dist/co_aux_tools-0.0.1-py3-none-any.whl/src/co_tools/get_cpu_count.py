#!/usr/bin/env python
import co_tools.co_utils as co_utils


def main():
    print(co_utils.get_cpu_limit())
    return 0


if __name__ == "__main__":
    sys.exit(main())
