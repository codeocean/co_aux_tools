src.co\_tools package
=====================

Submodules
----------

src.co\_tools.co\_fasta module
------------------------------

.. automodule:: src.co_tools.co_fasta
   :members:
   :undoc-members:
   :show-inheritance:

src.co\_tools.co\_fastq module
------------------------------

.. automodule:: src.co_tools.co_fastq
   :members:
   :undoc-members:
   :show-inheritance:

src.co\_tools.co\_utils module
------------------------------

.. automodule:: src.co_tools.co_utils
   :members:
   :undoc-members:
   :show-inheritance:

src.co\_tools.get\_cpu\_count module
------------------------------------

.. automodule:: src.co_tools.get_cpu_count
   :members:
   :undoc-members:
   :show-inheritance:

src.co\_tools.get\_dir\_contents module
---------------------------------------

.. automodule:: src.co_tools.get_dir_contents
   :members:
   :undoc-members:
   :show-inheritance:

src.co\_tools.get\_fasta\_file module
-------------------------------------

.. automodule:: src.co_tools.get_fasta_file
   :members:
   :undoc-members:
   :show-inheritance:

src.co\_tools.get\_fastq\_pair module
-------------------------------------

.. automodule:: src.co_tools.get_fastq_pair
   :members:
   :undoc-members:
   :show-inheritance:

src.co\_tools.get\_fwd\_fastqs module
-------------------------------------

.. automodule:: src.co_tools.get_fwd_fastqs
   :members:
   :undoc-members:
   :show-inheritance:

src.co\_tools.get\_groups module
--------------------------------

.. automodule:: src.co_tools.get_groups
   :members:
   :undoc-members:
   :show-inheritance:

src.co\_tools.get\_logger module
--------------------------------

.. automodule:: src.co_tools.get_logger
   :members:
   :undoc-members:
   :show-inheritance:

src.co\_tools.get\_pipeline\_confirm module
-------------------------------------------

.. automodule:: src.co_tools.get_pipeline_confirm
   :members:
   :undoc-members:
   :show-inheritance:

src.co\_tools.get\_read\_direction module
-----------------------------------------

.. automodule:: src.co_tools.get_read_direction
   :members:
   :undoc-members:
   :show-inheritance:

src.co\_tools.get\_read\_pattern module
---------------------------------------

.. automodule:: src.co_tools.get_read_pattern
   :members:
   :undoc-members:
   :show-inheritance:

src.co\_tools.get\_read\_prefix module
--------------------------------------

.. automodule:: src.co_tools.get_read_prefix
   :members:
   :undoc-members:
   :show-inheritance:

src.co\_tools.get\_rev\_file module
-----------------------------------

.. automodule:: src.co_tools.get_rev_file
   :members:
   :undoc-members:
   :show-inheritance:

src.co\_tools.set\_log\_msg module
----------------------------------

.. automodule:: src.co_tools.set_log_msg
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: src.co_tools
   :members:
   :undoc-members:
   :show-inheritance:
