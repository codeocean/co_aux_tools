.. Code Ocean Aux Tools documentation master file, created by
   sphinx-quickstart on Mon Mar 20 16:38:48 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Code Ocean Aux Tools's documentation!
================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
