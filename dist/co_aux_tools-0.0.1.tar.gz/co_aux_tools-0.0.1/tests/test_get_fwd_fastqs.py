import pytest
from pathlib import Path

# from testfixtures import TempDirectory
from src.codeoceanauxtools.co_fastq import get_fwd_fastqs


# @pytest.fixture(scope="session")
# def image_file(tmp_path_factory):
#     img = compute_expensive_image()
#     fn = tmp_path_factory.mktemp("data") / "img.png"
#     img.save(fn)
#     return fn


@pytest.fixture(scope="session")
def fastq_file(tmp_path_factory):
    # img = compute_expensive_image()
    fn = tmp_path_factory.mktemp("data") / "gsm123_R1.fastq.gz"
    img.save(fn)
    return fn


@pytest.fixture()
def fastq_dir(tmp_path):
    fastq_files = ['gsm123_R1.fastq.gz.txt', 'gsm123_R2.fastq.gz.txt', 'gsm124_R1.fastq.gz.txt', 'gsm124_R2.fastq.gz.txt']
    d = tmp_path / "datadir"
    d.mkdir()
    for fastq in fastq_files:
        Path(f"{d}/{fastq}").touch()
    # p = d / "gsm123_R1.fastq.gz"
    assert Path(d).is_dir()
    return d


# @pytest.fixture()
# def fastq_dir():
#     fastq_files = ['gsm123_R1.fastq.gz', 'gsm123_R2.fastq.gz', 'gsm124_R1.fastq.gz', 'gsm124_R2.fastq.gz']
#     with testfixtures.TempDirectory() as d:
#         for elem in fastq_files:
#             d.write(elem, b'some fastq thing')
#     return d


# Tests for get_fwd_fastqs
def test_get_fwd_fastqs(fastq_dir):
    fastq_files = ['gsm123_R1.fastq.gz.txt', 'gsm124_R1.fastq.gz.txt']
    for i,x in enumerate(get_fwd_fastqs(fastq_dir)):
        fastq = Path(fastq).name
        assert
    assert Path(get_fwd_fastqs(fastq_dir)).name == "gsm123_R1.fastq.gz gsm124_R1.fastq.gz"
