from src.co-tools.get_fasta_file import (find_extension,
                                                  find_fasta_file, main)

# Tests for find_extension
# TODO


# Tests for find_fasta_file
# TODO
